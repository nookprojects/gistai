/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['techcrunch.com', 'www.axios.com', 'assets.bwbx.io'],
  },
}
module.exports = nextConfig
